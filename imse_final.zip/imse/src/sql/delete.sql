/*DROP TABLES*/
drop table Fuehrt;
drop table Findet_statt;
drop table Zeit;
drop table Kursteilnehmer;
drop table Kochkurse;
drop table Koch;
drop table Manager;
drop table Mitarbeiter;
drop table Kueche;
drop table Kochschule;


